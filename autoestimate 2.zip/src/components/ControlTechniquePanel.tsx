import React, { useState } from "react";
import {
  ShieldAlert,
  Mail,
  Globe,
  Sparkles,
  Calendar,
  Phone,
  Upload,
  Camera,
  Check,
  CheckCircle2,
  Trash2,
  ExternalLink,
  Loader2,
  MailOpen,
  RefreshCw,
  AlertTriangle,
  Clock,
  CheckSquare
} from "lucide-react";

interface ControlTechniquePanelProps {
  selectedExpertise: any;
  updateExpertiseClientFields: (id: string, fields: any) => void;
  proProfile: any;
  expertises?: any[];
}

export default function ControlTechniquePanel({
  selectedExpertise,
  updateExpertiseClientFields,
  proProfile,
  expertises = [],
}: ControlTechniquePanelProps) {
  const [activeLang, setActiveLang] = useState<"fr" | "de" | "en">("fr");
  const [isOcrAnalyzing, setIsOcrAnalyzing] = useState(false);
  const [ocrStep, setOcrStep] = useState("");
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState("");

  const todayStr = "2026-05-26"; // Reference date
  const today = new Date(todayStr);

  const expiryDateStr = selectedExpertise.controlTechniqueExpiryDate || "";
  let daysRemaining: number | null = null;
  let isAlertActive = false;
  let targetEmailDateStr = "";

  if (expiryDateStr) {
    const expiry = new Date(expiryDateStr);
    const diffTime = expiry.getTime() - today.getTime();
    daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    isAlertActive = daysRemaining <= 45;

    // Calculate J-45 date
    const j45Date = new Date(expiry.getTime());
    j45Date.setDate(j45Date.getDate() - 45);
    targetEmailDateStr = j45Date.toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  }

  const clientName = selectedExpertise.clientName || "Client Estimé";
  const clientEmail = selectedExpertise.clientEmail || "client@garage-auto.com";
  const makeModel = selectedExpertise.vehicle?.makeModel || "Véhicule Client";
  const licensePlate = selectedExpertise.vehicle?.licensePlate || "AA-123-AA";
  const garageName = proProfile?.companyName || "Garage AutoEstimate Lux";
  const formattedExpiry = expiryDateStr
    ? new Date(expiryDateStr).toLocaleDateString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      })
    : "Non renseignée";

  // Scan & Keyword checking for EXISTING appointments
  const findExistingCTAppointment = () => {
    if (!expertises || !selectedExpertise) return null;

    const currentEmail = selectedExpertise.clientEmail?.toLowerCase().trim();
    const currentName = selectedExpertise.clientName?.toLowerCase().trim();
    const currentPlate = selectedExpertise.vehicle?.licensePlate?.replace(/[^a-zA-Z0-9]/g, "").toLowerCase().trim();

    const ctKeywords = [
      "contrôle technique", "controle technique", "ct", "hauptuntersuchung", "hu", "tüv", "tuv",
      "mot", "pré-contrôle", "pre-controle", "pre-inspection", "précontrôle", "precontrole",
      "pression", "technique", "inspection"
    ];

    return expertises.find((exp) => {
      // It must be a scheduled appointment
      if (!exp.appointmentDate) return false;

      // Identity Match (Client Email, Client Name, or License Plate)
      const emailMatch = currentEmail && exp.clientEmail?.toLowerCase().trim() === currentEmail;
      const nameMatch = currentName && exp.clientName?.toLowerCase().trim() === currentName;
      const plateMatch = currentPlate && exp.vehicle?.licensePlate?.replace(/[^a-zA-Z0-9]/g, "").toLowerCase().trim() === currentPlate;

      if (emailMatch || nameMatch || plateMatch) {
        // Search if subject has CT context
        const searchPool = `
          ${exp.damageSummary || ""} 
          ${exp.id} 
          ${exp.items?.map((i: any) => `${i.name || ""} ${i.category || ""} ${i.description || ""}`).join(" ") || ""}
        `.toLowerCase();
        
        return ctKeywords.some(kw => searchPool.includes(kw));
      }
      return false;
    });
  };

  const existingAppt = findExistingCTAppointment();

  // Simulate OCR Scan 
  const handleOcrSimulation = () => {
    setIsOcrAnalyzing(true);
    setOcrStep("Initialisation de l'appareil optique...");
    
    setTimeout(() => {
      setOcrStep("Extraction de la plaque et de la vignette...");
    }, 600);

    setTimeout(() => {
      setOcrStep("Analyse du timbre de Contrôle Technique (CT)...");
    }, 1200);

    setTimeout(() => {
      // Set to 2026-07-10 (which is exactly 45 days after 2026-05-26)
      const mockExpiry = "2026-07-10";
      updateExpertiseClientFields(selectedExpertise.id, {
        controlTechniqueExpiryDate: mockExpiry,
        controlTechniqueImageSrc: "https://images.unsplash.com/photo-1551524559-8af4e6624178?auto=format&fit=crop&q=80&w=600",
      });
      setIsOcrAnalyzing(false);
      setOcrStep("");
      triggerNotification("📷 Scan réussi ! Échéance au 10/07/2026 identifiée.");
    }, 2000);
  };

  const triggerNotification = (msg: string) => {
    setNotificationMsg(msg);
    setShowNotification(true);
    setTimeout(() => {
      setShowNotification(false);
    }, 4505);
  };

  // Simulate instant email alert
  const handleSendEmailSimulation = () => {
    if (existingAppt) {
      triggerNotification("⚠️ Envoi bloqué : Le client dispose déjà d'un RDV planifié pour son contrôle technique.");
      return;
    }
    updateExpertiseClientFields(selectedExpertise.id, {
      controlTechniqueEmailSent: true,
      controlTechniqueEmailSentDate: new Date().toLocaleDateString("fr-FR"),
    });
    triggerNotification("🚀 Relance e-mail multilingue (FR/DE/EN) enregistrée comme envoyée !");
  };

  const handleMailtoDispatch = () => {
    if (existingAppt) return;
    updateExpertiseClientFields(selectedExpertise.id, {
      controlTechniqueEmailSent: true,
      controlTechniqueEmailSentDate: new Date().toLocaleDateString("fr-FR"),
    });
    triggerNotification("📬 Client de messagerie lancé avec le modèle pré-rempli ! Statut de relance enregistré.");
  };

  const handleReset = () => {
    updateExpertiseClientFields(selectedExpertise.id, {
      controlTechniqueExpiryDate: null,
      controlTechniqueImageSrc: null,
      controlTechniqueEmailSent: false,
      controlTechniqueEmailSentDate: null,
    });
    triggerNotification("🔄 Données réinitialisées.");
  };

  // Content for Email Tabs
  const emailTemplates = {
    fr: {
      subject: `⚠️ Rappel : Échéance de votre contrôle technique pour votre ${makeModel}`,
      body: `Dossier de réparation : ${selectedExpertise.id}
Client : ${clientName}
Véhicule : ${makeModel} (${licensePlate})

Cher(e) ${clientName},

Nous tenons à vous informer que le contrôle technique légal de votre véhicule ${makeModel} (Plaques d'immatriculation : ${licensePlate}) arrive à expiration le ${formattedExpiry}.

Pour vous éviter les frais imprévus de contre-visite et rouler en toute conformité, notre atelier ${garageName} vous propose de réaliser un pré-contrôle technique approfondi. Nos techniciens examineront tous les organes indispensables de sécurité pour s'assurer que votre véhicule soit admis sans aucune remarque lors du test officiel.

Veuillez nous contacter ou nous répondre directement pour planifier un rendez-vous rapide.

Bien cordialement,
L'équipe ${garageName}`,
    },
    de: {
      subject: `⚠️ Erinnerung: Ablauf der Hauptuntersuchung für Ihren ${makeModel}`,
      body: `Fahrzeugakte: ${selectedExpertise.id}
Kunde: ${clientName}
Fahrzeug: ${makeModel} (${licensePlate})

Sehr geehrte(r) ${clientName},

wir möchten Sie darauf hinweisen, dass die gesetzliche Hauptuntersuchung (Contrôle Technique) für Ihr Fahrzeug ${makeModel} (Kennzeichen: ${licensePlate}) am ${formattedExpiry} fällig ist.

Um unerwartete Nachprüfungsgebühren oder Bußgelder zu vermeiden, bietet Ihnen die Werkstatt ${garageName} einen umfassenden kostenlosen Vorab-Sicherheitscheck an. Wir prüfen Bremsen, Abgaswerte, Beleuchtung und Achsen, um ein reibungsloses Bestehen der offiziellen Hauptuntersuchung zu gewährleisten.

Bitte kontaktieren Sie uns telefonisch oder antworten Sie auf diese E-Mail, um Ihren Wunschtermin zu reservieren.

Mit freundlichen Grüßen,
Ihr Team von ${garageName}`,
    },
    en: {
      subject: `⚠️ Reminder: Upcoming Vehicle Inspection (MOT) due for your ${makeModel}`,
      body: `Repair Dossier: ${selectedExpertise.id}
Client: ${clientName}
Vehicle: ${makeModel} (${licensePlate})

Dear ${clientName},

We would like to remind you that the mandatory safety inspection (Contrôle Technique) for your ${makeModel} (License Plate: ${licensePlate}) will expire on ${formattedExpiry}.

To help you avoid unexpected failing penalties and additional inspection fees, our dealership ${garageName} offers a thorough pre-inspection safety review. We will evaluate key aspects including brakes, lights, emissions, and suspension to secure a successful outcome on your official test.

Please reach out to us or respond to this email to book your appointment.

Best regards,
The ${garageName} Team`,
    },
  };

  return (
    <div className="flex flex-col min-h-[460px] bg-slate-50 border border-[#c4c6cd] rounded-2xl p-4 relative overflow-hidden">
      
      {/* Toast Notification */}
      {showNotification && (
        <div className="absolute top-3 left-3 right-3 z-50 bg-[#041627] text-white text-xs px-4 py-3 rounded-xl border border-amber-500/30 shadow-2xl flex items-center gap-2 animate-bounce">
          <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
          <p className="font-bold flex-grow text-left">{notificationMsg}</p>
        </div>
      )}

      {/* Header section */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200">
        <div className="text-left">
          <h4 className="text-xs font-black text-[#041627] uppercase tracking-wider flex items-center gap-1.5">
            <span className="p-1 rounded-md bg-amber-500/10 text-amber-600">
              <ShieldAlert className="w-4 h-4" />
            </span>
            CONTRÔLE TECHNIQUE & ALERTE J-45
          </h4>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Scan de la vignette, suivi d'expiration et envoi automatique de la relance multilingue.
          </p>
        </div>
        {selectedExpertise.controlTechniqueExpiryDate && (
          <button
            type="button"
            onClick={handleReset}
            title="Réinitialiser l'échéance"
            className="p-1 px-2.5 bg-slate-200/80 hover:bg-slate-300 text-slate-600 rounded-lg text-[9px] font-bold transition-all flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-2.5 h-2.5" />
            Réinitialiser
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-grow">
        
        {/* Left column: Scan state or Date Config */}
        <div className="lg:col-span-5 flex flex-col justify-between gap-4">
          
          {!selectedExpertise.controlTechniqueImageSrc ? (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-slate-300 rounded-xl bg-white shadow-xs">
              {isOcrAnalyzing ? (
                <div className="flex flex-col items-center py-6">
                  <Loader2 className="w-10 h-10 text-amber-600 animate-spin mb-3" />
                  <span className="text-xs font-black text-slate-700 uppercase tracking-widest animate-pulse">
                    Analyse OCR par IA...
                  </span>
                  <span className="text-[10px] text-amber-600 mt-2 italic font-mono">
                    {ocrStep}
                  </span>
                </div>
              ) : (
                <>
                  <div className="p-3.5 rounded-full bg-amber-500/10 text-amber-600 mb-3">
                    <ShieldAlert className="w-8 h-8" />
                  </div>
                  <h5 className="font-bold text-slate-700 text-xs mb-1">
                    Scanner le Contrôle Technique
                  </h5>
                  <p className="text-[10px] text-slate-500 max-w-xs leading-relaxed mb-4">
                    Glissez la photo du macaron / rapport, ou lancez la caméra mobile pour extraire automatiquement l'échéance réglementaire.
                  </p>
                  
                  <div className="flex flex-col gap-2 w-full">
                    <button
                      type="button"
                      onClick={handleOcrSimulation}
                      className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-extrabold text-[11px] rounded-xl shadow-xs transition-all cursor-pointer uppercase tracking-widest-xs"
                    >
                      <Camera className="w-4 h-4" />
                      Simuler Scan & Reconnaissance IA
                    </button>
                    
                    <label className="w-full cursor-pointer inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-extrabold text-[11px] rounded-xl transition-all">
                      <Upload className="w-3.5 h-3.5 text-slate-400" />
                      Importer un cliché
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            handleOcrSimulation();
                          }
                        }}
                      />
                    </label>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="flex-grow bg-white border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between shadow-xs">
              <div className="space-y-3">
                <div className="relative aspect-video rounded-lg overflow-hidden border border-slate-200">
                  <img
                    src={selectedExpertise.controlTechniqueImageSrc}
                    alt="Scan vignette CT"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-2">
                    <span className="text-[9px] font-mono text-white/90 font-bold">
                      Vignette_CT_Scanne_Rapport.png
                    </span>
                  </div>
                </div>

                {/* Expiry inputs and states */}
                <div className="space-y-1.5 text-left">
                  <label className="block text-[10px] font-bold text-slate-600 uppercase tracking-wider">
                    Échéance du Contrôle Technique :
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={expiryDateStr}
                      onChange={(e) => {
                        updateExpertiseClientFields(selectedExpertise.id, {
                          controlTechniqueExpiryDate: e.target.value,
                        });
                      }}
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                    <Calendar className="absolute right-3 top-2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                {/* Remaining alert visual block */}
                {expiryDateStr && (
                  <div className={`p-2.5 rounded-lg border flex items-center justify-between gap-2 text-left ${
                    isAlertActive 
                      ? "bg-rose-50 border-rose-100/80 text-rose-850" 
                      : "bg-emerald-55 bg-emerald-50 border-emerald-100 text-emerald-800"
                  }`}>
                    <div>
                      <p className="text-[9px] font-bold uppercase tracking-wider">
                        {isAlertActive ? "⚠️ Expire très bientôt" : "🟢 Statut Conforme"}
                      </p>
                      <p className="text-[11px] font-black mt-0.5">
                        {daysRemaining !== null 
                          ? `${daysRemaining} jours restants` 
                          : "Calcul en cours..."}
                      </p>
                    </div>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full ${
                      isAlertActive ? "bg-rose-100 text-rose-850 animate-pulse" : "bg-emerald-100 text-emerald-800"
                    }`}>
                      J-{daysRemaining}
                    </span>
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Right column: Multilingual Email Client Relance Simulator */}
        <div className="lg:col-span-7 flex flex-col">
          <div className="flex-grow bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col shadow-sm">
            
            {/* Email app header */}
            <div className="bg-slate-950 px-3 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-left">
                <span className="flex h-2 w-2 relative">
                  <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                    existingAppt 
                      ? "bg-rose-400" 
                      : selectedExpertise.controlTechniqueEmailSent 
                        ? "bg-emerald-400" 
                        : "bg-amber-400"
                  }`}></span>
                  <span className={`relative inline-flex rounded-full h-2 w-2 ${
                    existingAppt 
                      ? "bg-rose-500" 
                      : selectedExpertise.controlTechniqueEmailSent 
                        ? "bg-emerald-500" 
                        : "bg-amber-500"
                  }`}></span>
                </span>
                <span className="text-[9.5px] font-mono font-bold text-slate-400 tracking-wider">
                  {existingAppt 
                    ? "RELANCE SUPPENDUE (RDV TROUVÉ)"
                    : selectedExpertise.controlTechniqueEmailSent 
                      ? `RELANCE ENVOYÉE LE : ${selectedExpertise.controlTechniqueEmailSentDate}` 
                      : `ALERTE PROGRAMMÉE : ${targetEmailDateStr || "EN ATTENTE"}`}
                </span>
              </div>
              
              {/* Language switcher tab icons */}
              <div className="flex items-center gap-1">
                {(["fr", "de", "en"] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setActiveLang(lang)}
                    className={`p-1 px-2.5 font-bold text-[10px] rounded-md transition-all flex items-center gap-1 cursor-pointer uppercase ${
                      activeLang === lang 
                        ? "bg-slate-850 text-white border border-slate-700" 
                        : "text-slate-400 hover:text-white"
                    }`}
                  >
                    <span>{lang === "fr" ? "🇫🇷 FR" : lang === "de" ? "🇩🇪 DE" : "🇬🇧 EN"}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Email view */}
            <div className="p-3 text-left space-y-2 bg-slate-900 flex-grow overflow-y-auto max-h-[240px] scrollbar-none relative">
              
              {existingAppt ? (
                <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center text-center p-6 space-y-4">
                  <div className="w-12 h-12 rounded-full bg-rose-500/15 text-rose-500 flex items-center justify-center border border-rose-500/30">
                    <AlertTriangle className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="space-y-1.5">
                    <h5 className="font-extrabold text-[#fda4af] text-[12px] uppercase tracking-wider">
                      ⚠️ ENVOI DIPLOMATIQUE NEUTRALISÉ
                    </h5>
                    <p className="text-[10px] text-slate-300 max-w-xs leading-relaxed">
                      Ce client a déjà planifié un rendez-vous lié au <span className="font-semibold text-amber-400">Contrôle Technique</span>. Pour éviter toute confusion et préserver la relation client, l'e-mail automatique n'est pas expédié.
                    </p>
                  </div>
                  
                  <div className="border border-white/10 bg-slate-900 rounded-lg p-3 w-full max-w-xs text-left font-mono text-[9px] space-y-1 text-slate-300 shadow-inner">
                    <p><span className="text-slate-500">⚙️ Dossier ID :</span> {existingAppt.id}</p>
                    <p><span className="text-slate-500">📅 RDV fixé le :</span> <span className="text-emerald-400 font-bold">{existingAppt.appointmentDate}</span></p>
                    <p><span className="text-slate-500">✍️ Motif / Sujet :</span> {existingAppt.damageSummary || "Aucune note"}</p>
                  </div>
                </div>
              ) : null}

              <div className="text-[10.5px] border-b border-slate-800 pb-2 space-y-1 font-mono text-slate-400">
                <div><span className="text-slate-500">De :</span> {proProfile?.email || "notifications@garage-auto.be"} ({garageName})</div>
                <div><span className="text-slate-500">À :</span> {clientEmail}</div>
                <div>
                  <span className="text-slate-500">Sujet :</span>{" "}
                  <span className="text-amber-400 font-bold">{emailTemplates[activeLang].subject}</span>
                </div>
              </div>
              
              <div className="pt-1.5 whitespace-pre-wrap font-sans text-[11px] text-slate-300 leading-relaxed select-text">
                {emailTemplates[activeLang].body}
              </div>
            </div>

            {/* Bottom action trigger bar */}
            {(() => {
              const subjectEncoded = encodeURIComponent(emailTemplates[activeLang].subject);
              const bodyEncoded = encodeURIComponent(emailTemplates[activeLang].body);
              const mailtoUrl = `mailto:${clientEmail}?subject=${subjectEncoded}&body=${bodyEncoded}`;

              return (
                <div className="bg-slate-950 p-2.5 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2">
                  <span className="text-[9.5px] italic text-slate-500 font-mono hidden md:inline">
                    Anti-doublon CT & Mailto Actif
                  </span>
                  
                  {!expiryDateStr ? (
                    <div className="w-full text-center py-1.5 text-[10px] text-slate-500 tracking-wider font-bold">
                      Veuillez d'abord scanner ou configurer une date d'échéance.
                    </div>
                  ) : existingAppt ? (
                    <button
                      type="button"
                      disabled
                      className="w-full justify-center inline-flex items-center gap-1.5 px-4 py-2 bg-slate-850 text-slate-500 border border-slate-800 font-extrabold text-[10.5px] rounded-lg tracking-wider cursor-not-allowed uppercase text-center"
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Envoi Désactivé (RDV Trouvé)
                    </button>
                  ) : (
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                      <button
                        type="button"
                        onClick={handleSendEmailSimulation}
                        className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-705 border border-slate-700 hover:bg-slate-750 text-slate-300 hover:text-white font-extrabold text-[10px] rounded-lg tracking-wider transition-all cursor-pointer uppercase text-center"
                      >
                        <Clock className="w-3 h-3 text-slate-450" />
                        Tracer comme Envoyé J-45
                      </button>

                      <a
                        href={mailtoUrl}
                        onClick={handleMailtoDispatch}
                        className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] rounded-lg tracking-wider transition-all cursor-pointer uppercase text-center shadow-xs"
                      >
                        <Mail className="w-3.5 h-3.5 animate-pulse" />
                        Ouvrir & Envoyer (Mailto)
                      </a>
                    </div>
                  )}
                </div>
              );
            })()}

          </div>
        </div>

      </div>

    </div>
  );
}
