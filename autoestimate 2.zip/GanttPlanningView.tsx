import React from "react";
import { Filter, Search, ChevronLeft, ChevronRight, Settings, User as UserIcon } from "lucide-react";

export default function GanttPlanningView() {
  const days = [
    { name: "Lun. 11", columns: 14 },
    { name: "Mar. 12", columns: 14 },
    { name: "Mer. 13", columns: 14 },
    { name: "Jeu. 14", columns: 14 },
    { name: "Ven. 15", columns: 14 },
    { name: "Sam. 16", columns: 14 },
  ];

  const hours = [
    "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"
  ];

  const workers = [
    {
      name: "Hervé DUPOND",
      tasks: [
        { title: "Equilibrage 90-AQZ-09 / FORD Mustang", color: "bg-emerald-300", startCol: 8, colSpan: 6, dayOffset: 0 },
        { title: "Frein WW-135-XX / Nissan", color: "bg-blue-400", startCol: 11, colSpan: 3, dayOffset: 1 },
      ]
    },
    {
      name: "Jacques BLOND",
      tasks: [
        { title: "Peinture GR-373-TE / Range Rover Evoque \nMr Dufour", color: "bg-[#c5c6eb]", startCol: 0, colSpan: 70, dayOffset: 0 }, // stretches across almost all days, let's keep it simple
      ]
    },
    {
      name: "Roger VERT",
      tasks: [
        { title: "Contrôle technique 90-AQZ-09 / FORD Mustang \nMme Durand", color: "bg-[#e8f276]", startCol: 0, colSpan: 10, dayOffset: 0 },
        { title: "Equilibrage WW-135-XX / Nissan GT \nMme Martin", color: "bg-emerald-300", startCol: 10, colSpan: 4, dayOffset: 3 },
        { title: "Equilibrage 90-AQZ-09 / FORD Mustang \nMme Durand", color: "bg-emerald-300", startCol: 0, colSpan: 6, dayOffset: 4 },
        { title: "Frein SP-666-FC /", color: "bg-blue-400", startCol: 1, colSpan: 2, dayOffset: 5 },
      ]
    },
    {
      name: "Philippe PONCE",
      tasks: [
        { title: "Contrôle technique 90-AQZ-09 / FORD Mustang \nMme Durand", color: "bg-[#e8f276]", startCol: 0, colSpan: 10, dayOffset: 0 },
        { title: "Carrosserie SP-666-FC / Volkswagen EOS \nMr Muller", color: "bg-orange-400", startCol: 0, colSpan: 40, dayOffset: 1 },
        { title: "Révision 80-MXM-08 / BMW I8 \nMr Pierre", color: "bg-[#ed9ef5]", startCol: 0, colSpan: 10, dayOffset: 5 },
      ]
    },
    {
      name: "René GEORGES",
      tasks: [
        { title: "Révision WW-135-XX / Nissan GT \nMme G", color: "bg-gray-400 text-white", startCol: 0, colSpan: 10, dayOffset: 0 },
        { title: "Equilibrage / BMW", color: "bg-[#186b40] text-white", startCol: 8, colSpan: 5, dayOffset: 2 },
        { title: "Maladie", color: "bg-[#e63038] text-white", startCol: 0, colSpan: 30, dayOffset: 3 },
        { title: "Contrôle technique 90-AQZ-09 / FORD Mustang \nMme Genais", color: "bg-[#e8f276]", startCol: 0, colSpan: 10, dayOffset: 5 },
      ]
    },
    {
      name: "Pierre PAUL",
      tasks: [
        { title: "Peinture / Reparation", color: "bg-[#0b6de6] text-white", startCol: 0, colSpan: 12, dayOffset: 0 },
        { title: "Contrôle technique 60-BVR-60 / Mercedes Classe A \nMme Martin", color: "bg-[#8abd22]", startCol: 1, colSpan: 8, dayOffset: 1 },
        { title: "Contrôle technique 90-AQZ-09 / FORD Mustang \nMr Pierre", color: "bg-[#e8f276]", startCol: 0, colSpan: 10, dayOffset: 4 },
        { title: "Frein WW-135-XX /", color: "bg-blue-400 text-white", startCol: 1, colSpan: 2, dayOffset: 5 },
      ]
    }
  ];

  return (
    <div className="bg-white border border-[#c4c6cd] flex flex-col font-sans text-xs overflow-hidden shadow-md mt-4" style={{ height: "calc(100vh - 250px)" }}>
      {/* Header bar mirroring PlanningPME style */}
      <div className="bg-[#489ddb] text-white flex items-center justify-between px-2 py-1 shrink-0">
        <div className="flex items-center gap-2">
          <div className="bg-white p-1 rounded-sm text-[#489ddb] font-black text-[10px] flex items-center gap-1">
            <div className="w-5 h-5 bg-[#489ddb] text-white rounded-[2px] flex items-center justify-center">
              P
            </div>
            PlanningPME
          </div>
          <button className="bg-[#5eaee5] px-2 py-1 flex items-center gap-1 hover:bg-[#68bcfa]">
            <span className="font-bold text-lg leading-none mt-[-2px]">+</span> Ressources ▼
          </button>
          <div className="flex bg-[#5eaee5] rounded hover:bg-[#68bcfa]">
            <button className="px-2 py-1 border-r border-[#68bcfa]">Hebdomada ▼</button>
            <button className="px-2 py-1 border-r border-[#68bcfa]">11/02/2019</button>
            <button className="px-2 py-1">Service... ▼</button>
          </div>
          <button className="p-1 hover:bg-[#68bcfa]"><Filter className="w-4 h-4 fill-current" /></button>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <span className="absolute left-2 top-1.5"><Search className="w-3 h-3 text-slate-300" /></span>
            <input type="text" className="bg-white text-slate-800 h-6 w-48 pl-6 pr-2 outline-none text-xs" />
          </div>
          <div className="flex bg-[#5eaee5] items-center">
            <button className="px-1.5 hover:bg-[#68bcfa] border-r border-[#68bcfa] h-6"><ChevronLeft className="w-4 h-4" /></button>
            <span className="px-2 font-bold text-[10px] bg-white text-slate-800 h-6 flex items-center shadow-inner">1 / 1</span>
            <button className="px-1.5 hover:bg-[#68bcfa] h-6"><ChevronRight className="w-4 h-4" /></button>
          </div>
          <button className="bg-white text-slate-800 px-2 h-6 flex items-center font-bold">10</button>
          
          <button className="p-1 hover:bg-[#68bcfa]"><Search className="w-4 h-4" /></button>
          <button className="p-1 hover:bg-[#68bcfa]"><ChevronDownIcon className="w-4 h-4" /></button>
          <button className="p-1 hover:bg-[#68bcfa]"><Settings className="w-4 h-4" /></button>
          <button className="p-1 hover:bg-[#68bcfa]"><UserIcon className="w-4 h-4" /></button>
        </div>
      </div>

      {/* Sub Header row */}
      <div className="bg-[#6db3e6] text-white flex px-2 py-1 items-center gap-4 text-[10px] shrink-0 border-b-2 border-slate-300">
        <button><Filter className="w-3 h-3 inline mr-1 fill-current"/>Filtre ▼</button>
        <button>Catégorie... ▼</button>
        <button>Client... ▼</button>
        <button>Rendez-vou ▼</button>
        <span className="ml-auto text-white/80">Février 2019 / Sem. 7</span>
      </div>

      {/* Gantt Grid Container */}
      <div className="flex-1 overflow-auto flex bg-[#f5f6f8]">
        
        {/* Frozen Left Column: Users */}
        <div className="w-48 shrink-0 border-r-2 border-slate-300 bg-white shadow-sm z-10 sticky left-0 flex flex-col">
          <div className="h-12 border-b border-slate-300 shrink-0 bg-white flex flex-col items-center justify-center relative">
             <div className="text-slate-400 absolute left-2 top-2 text-[10px]">Filtre</div>
             <div className="w-8 h-8 flex flex-col justify-center items-center opacity-30 mt-2">
                <div className="w-4 h-4 border-2 border-slate-600 rounded-full"></div>
                <div className="w-2 h-2 bg-slate-600 rounded-lg translate-y-[-6px]"></div>
             </div>
          </div>
          {workers.map((w, idx) => (
            <div key={idx} className="h-20 border-b border-slate-200 px-2 flex items-center overflow-hidden">
               <span className="font-medium text-slate-800 text-[11px] truncate" title={w.name}>{w.name}</span>
            </div>
          ))}
        </div>

        {/* Scrollable Right Area: Timeline & Tasks */}
        <div className="flex flex-col flex-1 min-w-max">
           
           {/* Timeline Header */}
           <div className="flex h-12 border-b border-slate-300 bg-white shrink-0 sticky top-0 z-[5]">
             {days.map((d, i) => (
                <div key={i} className="flex flex-col border-r border-slate-300" style={{ width: d.columns * 22 }}>
                   <div className="h-6 border-b border-slate-200 flex items-center justify-center text-[11px] text-slate-800 font-medium bg-[#f0f4f9]">
                      {d.name}
                   </div>
                   <div className="h-6 flex text-[#8c9bb0] text-[9px] w-full">
                      {hours.map(h => (
                         <div key={h} className="flex-1 border-r border-slate-100 flex items-center justify-center w-[22px]">
                           {h}
                         </div>
                      ))}
                   </div>
                </div>
             ))}
           </div>

           {/* Tasks Matrix */}
           <div className="flex flex-col bg-white">
             {workers.map((w, rowIndex) => (
                <div key={rowIndex} className="h-20 border-b border-slate-100 flex relative group hover:bg-blue-50/30">
                  {/* Grid Lines */}
                  <div className="absolute inset-0 flex pointer-events-none">
                    {days.map((d, di) => (
                      <div key={di} className="flex border-r border-slate-300/50" style={{ width: d.columns * 22 }}>
                         {hours.map(h => (
                           <div key={h} className="flex-1 border-r border-slate-100/40 w-[22px] min-h-full"></div>
                         ))}
                      </div>
                    ))}
                  </div>

                  {/* Task Blocks */}
                  {w.tasks.map((task, idx) => {
                     const totalColWidth = 22; // 22px per hour column
                     const leftOffset = (task.dayOffset * 14 * totalColWidth) + (task.startCol * totalColWidth);
                     const width = task.colSpan * totalColWidth;
                     return (
                       <div 
                         key={idx} 
                         className={`absolute top-2 bottom-2 ${task.color} border border-black/10 overflow-hidden px-1 py-1 whitespace-pre-wrap leading-[1.1] z-10 shadow-sm transition-transform hover:scale-[1.01] hover:shadow cursor-pointer hover:z-20`}
                         style={{ left: leftOffset, width: Math.max(width, 22) }}
                       >
                         {task.title.split('\n').map((line, lidx) => (
                           <div key={lidx} className={`${lidx === 0 ? "font-bold" : ""} text-[9px]`}>{line}</div>
                         ))}
                       </div>
                     );
                  })}
                </div>
             ))}
           </div>

        </div>

      </div>
    </div>
  );
}

function ChevronDownIcon({ className }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m6 9 6 6 6-6"/></svg>;
}
