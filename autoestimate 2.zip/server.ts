import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

// Allow large base64 image uploads
app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ limit: "15mb", extended: true }));

// Helper for lazy loading Gemini GenAI SDK client
let aiInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY non configurée. Veuillez ajouter votre clé dans le panneau Settings > Secrets.");
  }
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiInstance;
}

// Durable wrapper to automatically handle 503 "UNAVAILABLE" or 429 "Resource exhausted" / "high demand" errors
async function callGeminiWithRetry<T>(fn: () => Promise<T>, retries = 4, delay = 1000): Promise<T> {
  try {
    return await fn();
  } catch (error: any) {
    const errorStr = JSON.stringify(error);
    const has503 = error.status === 503 || error.code === 503 || errorStr.includes("503") || error.message?.includes("503");
    const has429 = error.status === 429 || error.code === 429 || errorStr.includes("429") || error.message?.includes("429");
    const isTempUnavailable = has503 || has429 || 
                               error.message?.includes("UNAVAILABLE") || 
                               error.message?.includes("high demand") || 
                               error.message?.includes("temporary") ||
                               errorStr.includes("UNAVAILABLE") ||
                               errorStr.includes("high demand");

    if (isTempUnavailable && retries > 0) {
      console.warn(`[Gemini Retry] Service temporairement indisponible (503/429/Charge). Tentative d'auto-recouvrement dans ${delay}ms... (${retries} restant)`);
      await new Promise((resolve) => setTimeout(resolve, delay));
      return callGeminiWithRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
}

// ------------------- API ROUTES -------------------

// 1. Diagnostics damage analysis API endpoint
  app.post("/api/analyze-damage", async (req, res) => {
    try {
      const { image, images, previousAttemptsCount = 0, catalogueConnected } = req.body;
      const ai = getGeminiClient();
  
      let contents: any[] = [];
      
      // Support multiple images
      const imagesToProcess = images || (image ? [image] : []);
      
      for (const img of imagesToProcess) {
        if (img && img.startsWith("data:")) {
          // Decode base64
          const commaIndex = img.indexOf(",");
          const mimeType = img.substring(5, img.indexOf(";"));
          const base64Data = img.substring(commaIndex + 1);
          contents.push({
            inlineData: {
              mimeType,
              data: base64Data,
            },
          });
        }
      }
  
      const oemInstructions = catalogueConnected ? 
  `RÈGLES DE TARIFICATION (PARTSLINK24 IMPORTANTE) :
  L'atelier a activé le module "Catalogue PartsLink24". Vous êtes directement connecté à la base de données de pièces OEM du constructeur.
  VOUS DEVEZ IMPÉRATIVEMENT chiffrer les réparations avec des prix EXTRÊMEMENT PRÉCIS, RÉALISTES ET SPÉCIFIQUES À LA MARQUE pour des pièces certifiées OEM. Ne générez aucun tarif de pièce générique. Soyez ultra précis sur le nom de chaque pièce et prévoyez le coût de démontage/remontage dans la main d'œuvre.
  
  Voici un échantillon de tarifs PartsLink24 pré-validés à utiliser EN PRIORITÉ si les dégâts s'y prêtent, sinon déduisez les bons tarifs originaux :
  - "Cache sous moteur droit VW" (OEM: 1K0 825 237 AG) -> Prix: 65.50 €
  - "Spoiler de pare-chocs avant OEM" (OEM: 5G0 805 903 B) -> Prix: 112.00 €
  - "Condenseur de clim. (Audi/VW)" (OEM: 5QA 820 411 B) -> Prix: 298.50 €
  - "Commodo de clignotant standard" (OEM: 1K0 953 513 G) -> Prix: 85.00 €
  - "Phare gauche Full LED" (OEM: 5G0 941 035) -> Prix: 850.00 €
  - "Pare-chocs avant nu" (OEM: 8W0 807 065) -> Prix: 420.00 €
  - "Disque de frein avant (x2)" (OEM: 1J0 615 301 M) -> Prix: 115.00 €
  - "Triangle de suspension D/G" (OEM: 1T0 407 151 H) -> Prix: 145.00 €
  - "Serrure de capot VAG" (OEM: 7P0 823 509) -> Prix: 78.00 €
  - "Support de plaque (Audi)" (OEM: 8P0 807 285) -> Prix: 45.00 €
  
  Chez TOYOTA (Toyota Yaris, Yaris Cross, Yaris GR, etc.), l'aile arrière (aile arrière gauche ou aile arrière droite) a un tarif officiel d'usine strict de 970.00 € HT. Si vous chiffrez un dégât ou un remplacement d'aile arrière sur une Toyota Yaris, vous DEVEZ fixer le coût de la pièce d'origine à EXACTEMENT 970.00 € HT.
  
  Ajoutez TOUJOURS la mention "[PartsLink24 OEM]" dans la description de chaque pièce chiffrée.` : 
  `RÈGLES DE TARIFICATION (CATALOGUE DÉCONNECTÉ) :
  L'atelier n'a pas activé le module "Catalogue PartsLink24". Vous ne pouvez PAS proposer de vraies pièces OEM certifiées car vous n'avez pas accès à la base de données.
  Vous devez fournir une ESTIMATION GÉNÉRIQUE des pièces endommagées avec des prix "adaptables" ou d'occasion moins chers, en ajoutant impérativement la mention "[Pièce adaptable générique]" à la fin de la description.
  N'utilisez en aucun cas de références de constructeur. Les approximations sur les pièces génériques sont attendues (les phares, pare-chocs et pièces de carrosserie sont des pièces compatibles, non OEM).`;
  
      const defaultPrompt = `Vous êtes un expert en chiffrage automobile de très haut niveau travaillant pour une assurance automobile (AutoEstimate).
  Votre tâche absolue est d'analyser MINUTIEUSEMENT et EXHAUSTIVEMENT toutes les photos fournies pour lister *absolument toutes* les pièces endommagées, manquantes, arrachées, rayées ou impactées sur le véhicule présenté. 
  
  RÈGLES D'ANALYSE STRICTES :
  1. NE PRÉSUMEZ RIEN : Si une pièce (comme un phare, un capot, une jante) n'a visiblement aucun dégât, NE L'INCLUEZ PAS. Ne pas inventer de dégâts imaginaires sur des optiques ou pare-brises s'ils sont intacts.
  2. IDENTIFIEZ CE QUI MANQUE : Soyez particulièrement attentif aux pièces qui ont été ARRACHÉES ou DÉMONTÉES, telles que les "tours d'aile" (élargisseurs d'aile), les passages de roue en plastique, les protections sous carrosserie, ou les caches de pare-chocs.
  3. SOYEZ PRÉCIS : Décrivez ce que vous voyez réellement (exemple: "Tour d'aile avant droit manquant/arraché", "Garniture de passage de roue arrachée").
  
  Si l'image n'est pas claire, est trop sombre, ou s'il n'y a pas d'image du tout, simulez (improvisez) un cas de sinistre complet et réaliste impliquant des dommages variés. Mais si une image CHANTIER/GARAGE claire est fournie, basez-vous 100% sur ce qui y figure !
  
  ${oemInstructions}
  
  Générez la réponse au format JSON valide selon le schéma requis qui contient la marque/modèle du véhicule estimé, le numéro d'expertise unique généré (format EXP-XXXXX), la date du jour, une note finale détaillée de l'expert confirmant les détails observationnels concrets, les hotspots (points interactifs de collision sur l'image à afficher avec x,y coordonnés de 0 à 100 où l'origine est en haut à gauche de l'image pointant EXACTEMENT là où le dommage ou le trou est situé), et le détail des lignes de devis contenant les prix estimatifs en Euros (€).
  
  Assurez-vous d'avoir:
  - De nombreuses lignes avec pour catégorie "Pièces" correspondant rigoureusement UNIQUEMENT à ce qui est détecté comme endommagé ou arraché.
  - Au moins une voire plusieurs lignes de "Main d'œuvre" (ex: "Main d'œuvre carrosserie T1/T2", "Main d'œuvre peinture")
  - Les coordonnées x et y des hotspots doivent s'aligner exactement sur les zones abîmées ou sur le vide laissé par les pièces manquantes (comme un tour d'aile).`;

    contents.push({ text: defaultPrompt });

    const response = await callGeminiWithRetry(() => ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["vehicle", "expertiseId", "date", "damageSummary", "hotspots", "items"],
          properties: {
            vehicle: {
              type: Type.OBJECT,
              required: ["makeModel", "licensePlate", "vin"],
              properties: {
                makeModel: { type: Type.STRING, description: "Marque et modèle du véhicule décelé, ex: Audi A4 (2022)" },
                licensePlate: { type: Type.STRING, description: "Plaque d'immatriculation décelée ou simulée" },
                vin: { type: Type.STRING, description: "Numéro de Châssis VIN simulé valide de 17 caractères" },
              },
            },
            expertiseId: { type: Type.STRING, description: "Numéro de chiffrage unique comme EXP-88921" },
            date: { type: Type.STRING, description: "Date au format JJ/MM/AAAA" },
            damageSummary: { type: Type.STRING, description: "Note finale textuelle rédigée en français de l'Expert récapitulant les contrôles à effectuer" },
            hotspots: {
              type: Type.ARRAY,
              description: "Liste des points d'intérêts des dégâts identifiés",
              items: {
                type: Type.OBJECT,
                required: ["x", "y", "part", "status", "severity"],
                properties: {
                  x: { type: Type.INTEGER, description: "Coordonnée X en pourcentage sur l'image (de 0 à 100)" },
                  y: { type: Type.INTEGER, description: "Coordonnée Y en pourcentage sur l'image (de 0 à 100)" },
                  part: { type: Type.STRING, description: "Nom de la pièce, ex: Phare gauche (Matrix LED)" },
                  status: { type: Type.STRING, description: "Diagnostic, ex: Fissuré et cassé" },
                  severity: { type: Type.STRING, description: "Sévérité, ex: 'error' (grave) ou 'warning' (moyen)" },
                },
              },
            },
            items: {
              type: Type.ARRAY,
              description: "Lignes de devis",
              items: {
                type: Type.OBJECT,
                required: ["category", "name", "description", "cost"],
                properties: {
                  category: { type: Type.STRING, description: "Catégorie de ligne: Pièces ou Main d'œuvre" },
                  name: { type: Type.STRING, description: "Nom de la pièce ou tâche" },
                  description: { type: Type.STRING, description: "Description de l'intervention, ex: Remplacement ou Heures de travail" },
                  cost: { type: Type.NUMBER, description: "Montant HT/TTC d'imputations en Euros, ex: 845.0" },
                },
              },
            },
          },
        },
      },
    }));

    const textOutput = response.text || "{}";
    res.json(JSON.parse(textOutput));
  } catch (error: any) {
    console.error("Erreur d'analyse de dégâts:", error);
    res.status(500).json({ error: error.message || "Erreur lors de l'analyse avec Gemini" });
  }
});

// 2. OCR "Carte Grise" document details extraction API
app.post("/api/extract-car-card", async (req, res) => {
  try {
    const { image } = req.body;
    const ai = getGeminiClient();

    let contents: any[] = [];
    if (image && image.startsWith("data:")) {
      const commaIndex = image.indexOf(",");
      const mimeType = image.substring(5, image.indexOf(";"));
      const base64Data = image.substring(commaIndex + 1);
      contents.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    const ocrPrompt = `Vous êtes un outil d'extraction OCR de documents administratifs de véhicules français (Carte Grise / certificat d'immatriculation).
Extrayez fidèlement les informations visibles. Si le document ne fournit pas de détails nets ou si l'image est absente, simulez des données cohérentes et réalistes pour éviter les champs vides.
Traduisez ou formatez les données comme requis dans le schéma JSON:
- nomComplet: Nom complet du titulaire principal du document (ex: Jean Dupont)
- adresse: Adresse complète du titulaire
- idDocument: Numéro de document ou d'immatriculation de référence (ex: 2023FR-8921-JD)
- marqueModele: Marque & Modèle du véhicule (ex: Peugeot 208 ou Renault Clio)
- immatriculation: Plaque d'immatriculation (format français typique AA-123-BB)
- vin: Numéro de Châssis VIN (17 caractères commençant par VF...)
- miseEnCirc: Date de première mise en circulation (format JJ/MM/AAAA)
- energie: Carburant utilisé (Essence, Diesel, Électrique, Hybride)`;

    contents.push({ text: ocrPrompt });

    const response = await callGeminiWithRetry(() => ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["nomComplet", "adresse", "idDocument", "marqueModele", "immatriculation", "vin", "miseEnCirc", "energie"],
          properties: {
            nomComplet: { type: Type.STRING },
            adresse: { type: Type.STRING },
            idDocument: { type: Type.STRING },
            marqueModele: { type: Type.STRING },
            immatriculation: { type: Type.STRING },
            vin: { type: Type.STRING },
            miseEnCirc: { type: Type.STRING },
            energie: { type: Type.STRING },
          },
        },
      },
    }));

    const textOutput = response.text || "{}";
    res.json(JSON.parse(textOutput));
  } catch (error: any) {
    console.error("Erreur d'extraction de la carte grise:", error);
    res.status(500).json({ error: error.message || "Erreur d'extraction OCR avec Gemini" });
  }
});

// ------------------- FRAMEWORK SETUP -------------------

// Mount Vite middleware in development, serve static production bundle in production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Serveur d'AutoEstimate fonctionnel sur le port ${PORT}`);
  });
}

startServer();
